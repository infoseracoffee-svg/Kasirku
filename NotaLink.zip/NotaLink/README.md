# NotaLink

Aplikasi manajemen transaksi, kasir (POS), dan invoicing.

## Struktur Proyek
- `public/`: Frontend statis
- `api/`: Vercel Serverless Functions
- `src/`: Logika dan utils
- `supabase/`: Migrasi database
- `server/`: Setup untuk VPS/Docker
