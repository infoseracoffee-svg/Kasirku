-- Migration: Saldo Table
CREATE TABLE saldo (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  balance DECIMAL(15,2) DEFAULT 0
);