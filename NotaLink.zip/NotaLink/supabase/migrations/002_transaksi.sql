-- Migration: Transaksi Table
CREATE TABLE transaksi (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  amount DECIMAL(10,2),
  status VARCHAR(50)
);