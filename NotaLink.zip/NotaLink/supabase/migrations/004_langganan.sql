-- Migration: Langganan Table
CREATE TABLE langganan (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  plan_name VARCHAR(100)
);