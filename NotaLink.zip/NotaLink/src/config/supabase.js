// Supabase client configuration
export const supabase = {};