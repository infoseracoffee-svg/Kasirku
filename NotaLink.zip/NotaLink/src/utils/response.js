export const success = (data) => ({ success: true, data });
export const error = (msg) => ({ success: false, message: msg });