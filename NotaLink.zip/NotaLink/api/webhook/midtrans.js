module.exports = (req, res) => {
  // Midtrans webhook handler
  res.status(200).send('OK');
};