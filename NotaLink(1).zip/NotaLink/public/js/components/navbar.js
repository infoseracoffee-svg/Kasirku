// Navbar component
