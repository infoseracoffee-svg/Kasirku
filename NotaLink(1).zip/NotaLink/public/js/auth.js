// Authentication UI logic
