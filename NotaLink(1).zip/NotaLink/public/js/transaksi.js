// Transaction UI logic
