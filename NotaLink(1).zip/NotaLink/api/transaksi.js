// Vercel Function: transaction endpoints
