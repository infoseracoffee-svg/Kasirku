// Vercel Function: payment initiation
