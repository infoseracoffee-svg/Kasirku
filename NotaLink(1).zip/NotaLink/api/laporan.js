// Vercel Function: reporting endpoints
