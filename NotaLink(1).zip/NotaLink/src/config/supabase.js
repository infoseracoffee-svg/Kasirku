// Supabase server configuration
