// Reporting business logic
