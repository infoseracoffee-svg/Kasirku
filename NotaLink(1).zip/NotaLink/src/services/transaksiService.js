// Transaction business logic
