// Payment business logic
