// Input validation helpers
