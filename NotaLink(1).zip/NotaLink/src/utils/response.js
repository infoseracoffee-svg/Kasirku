// API response helpers
